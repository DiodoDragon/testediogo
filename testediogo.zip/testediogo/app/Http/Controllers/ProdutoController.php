<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Produto;

class ProdutoController extends Controller
{
    public function index(){
        return view('Welcome');
    }

    public function enviar(Request $request){
        $produto = new Produto();

        $produto->NomeProduto = $request->get('NomeProduto');
        $produto->Categoria = $request->get('Categoria');
        $produto->PrecoUnitario = $request->get('PrecoUnitario');
        $produto->Descricao = $request->get('Descricao');

        $produto->save();

        echo "Sua mensagem foi armazenada com sucesso! Código: " . $produto->id;
    }

    public function lista(){
        return view('lista', array('Produtos'=>Produto::all()));
    }
}
