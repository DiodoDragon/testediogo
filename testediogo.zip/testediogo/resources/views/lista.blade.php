<!DOCTYPE html>
<html lang="en">

<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/style.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="container">
        <h1>Lista de produtos</h1>
        <hr />
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nome do Produto</th>
                    <th>Categoria</th>
                    <th>Preço Unitário</th>
                    <th>Descrição</th>
                </tr>
            </thead>
            <tbody>
                @foreach($produtos as $row)
                <tr>
                    <th scope="row">{{ $row->CodigoProduto }}</th>
                    <td>{{ $row->NomeProduto }}</td>
                    <td>{{ $row->Categoria }}</td>
                    <td>{{ $row->PrecoUnitario }}</td>
                    <td>{{ $row->Descricao }}</td>
                </tr>
                @endforeach
            </tbody>

        </table>
    </div>
</body>

</html>