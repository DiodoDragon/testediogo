<?php

use Illuminate\Support\Facades\Route;

Route::get('/', 'App\Http\Controllers\ProdutoController@index');
Route::post('/enviar', 'App\Http\Controllers\ProdutoController@enviar');
Route::get('/lista', 'App\Http\Controllers\ProdutoController@lista');


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::post('/enviar', function(Illuminate\Http\Request $request) {
    $produtos = new App\Models\Produto();
    $produtos->CodigoProduto = $request->get('CodigoProduto');
    $produtos->NomeProduto = $request->get('NomeProduto');
    $produtos->Categoria =  $request->get('Categoria');
    $produtos->PrecoUnitario = $request->get('PrecoUnitario');
    $produtos->Descricao = $request->get('Descricao');

    $produtos->save();

    echo "teu pai careca: ". $produtos->CodigoProduto;


});

Route::get('/lista', function () {
    return view('lista', array('produtos' => App\Models\Produto::all()));
});