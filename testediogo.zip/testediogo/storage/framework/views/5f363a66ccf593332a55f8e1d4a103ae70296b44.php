<!DOCTYPE html>
<html>

<head>

    <title>Teste</title>

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">


</head>

<body >
    <div class="container">

    <form action="/enviar" method="POST">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

        <div class="form-group">
            <label>Código do Produto</label>
            <input type="text" name="CodigoProduto" id="codprod" class="form-control" placeholder="Código do Produto">
        </div>
        <div class="form-group">
            <label>Nome do Produto</label>
            <input type="text" name="NomeProduto" id="nomeprod" class="form-control" placeholder="Nome do Produto">
        </div>
        <div class="form-group">
            <label>Categoria</label>
            <input type="text" name="Categoria" id="categoria" class="form-control" placeholder="Categoria">
        </div>
        <div class="form-group">
            <label>Preço Unitário</label>
            <input type="text" name="PrecoUnitario" id="precounit" class="form-control" placeholder="Preço Unitário">
        </div>
        <div class="form-group">
            <label>Descrição</label>
            <input type="text" name="Descricao" id="descricao" class="form-control" placeholder="Descrição">
        </div>
        <button type="submit" class="btn btn-default">Enviar</button>

    </form>


    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\testediogo\resources\views/welcome.blade.php ENDPATH**/ ?>