<!DOCTYPE html>
<html lang="en">

<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/style.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="container">
        <h1>Lista de produtos</h1>
        <hr />
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nome do Produto</th>
                    <th>Categoria</th>
                    <th>Preço Unitário</th>
                    <th>Descrição</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($row->CodigoProduto); ?></th>
                    <td><?php echo e($row->NomeProduto); ?></td>
                    <td><?php echo e($row->Categoria); ?></td>
                    <td><?php echo e($row->PrecoUnitario); ?></td>
                    <td><?php echo e($row->Descricao); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\testediogo\resources\views/lista.blade.php ENDPATH**/ ?>